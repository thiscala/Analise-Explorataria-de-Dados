# thiago-scala
Repositório criado para o envio de resolução de exercícios pelos alunos de IAED, turma 2021/2022.
