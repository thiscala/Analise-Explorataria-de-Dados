# tf-thiago-scala
Repositório para entrega do Tópico 10 - Trabalho Final da disciplina optativa IAED 2021/2022.
